# How to get IMU/foot contact data and set cooling speed?
```bash
cd BRUCE-OP
```

### Run BRUCE SENSE
```bash
python3 -m Examples.bruce_sense.run_sense
```