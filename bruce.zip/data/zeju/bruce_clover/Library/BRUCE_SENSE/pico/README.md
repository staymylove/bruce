# How to program Raspberry Pi Pico without Arduino IDE?

### Step 1 - Hold BOOT while plugging in the Pico.

### Step 2 - Drag and drop ``pico.ino.uf2`` onto the drive. It should flash and reboot and just work.